{
    "test key one": "initialised to test key one",
    "test {0} one": "thar be the {0} one"
}