{
    "test key one": "This is test key one, YO!",
    "test {0} one": "This be {0} one, YO!"
}