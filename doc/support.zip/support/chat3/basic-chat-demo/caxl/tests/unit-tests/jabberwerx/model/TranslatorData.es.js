{
    "test key one": "clave pruebar uno",
    "test {0} one": "{0} pruebar uno"
}